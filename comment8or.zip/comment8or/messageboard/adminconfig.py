from django.contrib.admin.apps import AdminConfig

class MessageboardAdminConfig(AdminConfig):
    default_site = 'admin.Comment8orAdminSite'
